#!/bin/bash

echo "🗑️  Uninstalling Mental Note CLI..."

# Remove binaries
for dir in "$HOME/.local/bin" "$HOME/bin" "/usr/local/bin"; do
    if [ -f "$dir/mental-note" ]; then
        rm -f "$dir/mental-note"
        echo "   Removed: $dir/mental-note"
    fi
    if [ -f "$dir/mn" ]; then
        rm -f "$dir/mn"
        echo "   Removed: $dir/mn"
    fi
done

echo ""
echo "✅ Mental Note CLI uninstalled"
echo ""
echo "📁 Your notes are preserved at: ~/.mental-notes/"
echo "   Delete manually if you want to remove all data:"
echo "   rm -rf ~/.mental-notes/"
