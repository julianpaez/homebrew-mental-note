#!/bin/bash

echo "📦 Installing Mental Note CLI..."

# Determine install directory
if [ -d "$HOME/.local/bin" ] || mkdir -p "$HOME/.local/bin" 2>/dev/null; then
    INSTALL_DIR="$HOME/.local/bin"
elif [ -d "$HOME/bin" ] || mkdir -p "$HOME/bin" 2>/dev/null; then
    INSTALL_DIR="$HOME/bin"
else
    echo "❌ Cannot create installation directory"
    echo "   Please create ~/.local/bin or ~/bin manually"
    exit 1
fi

echo "   Installing to: $INSTALL_DIR"

# Copy binary
cp mental-note "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/mental-note"

# Create shortcut alias
ln -sf "$INSTALL_DIR/mental-note" "$INSTALL_DIR/mn"

# Check if install directory is in PATH
if [[ ":$PATH:" != *":$INSTALL_DIR:"* ]]; then
    echo "⚠️  $INSTALL_DIR is not in your PATH"
    echo "   Add this line to your shell profile:"
    echo "   export PATH=\"\$PATH:$INSTALL_DIR\""
    echo ""
    echo "   For bash: echo 'export PATH=\"\$PATH:$INSTALL_DIR\"' >> ~/.bashrc"
    echo "   For zsh:  echo 'export PATH=\"\$PATH:$INSTALL_DIR\"' >> ~/.zshrc"
    echo ""
    echo "   Then restart your terminal or run: source ~/.bashrc"
else
    echo "✅ $INSTALL_DIR is already in PATH"
fi

echo ""
echo "✅ Mental Note CLI installed successfully!"
echo ""
echo "🚀 Quick start:"
echo "   mental-note --help"
echo "   mn add remember 'Important meeting tomorrow'"
echo "   mn add do 'Complete project' --tags work,urgent"
echo "   mn list"
echo "   mn timeline"
echo ""
echo "📚 Full documentation: see QUICKSTART.md"
