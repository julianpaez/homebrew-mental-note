# Mental Note CLI v1.9.6

Modern CLI for managing mental notes, tasks, and ideas.

## Quick Install

```bash
./install.sh
```

## Quick Start

```bash
# Add notes with different action types
mn add remember "Important meeting tomorrow"
mn add do "Complete project" --tags work,urgent
mn add contemplate "New business idea"

# Manage tasks
mn done 1                    # Mark task completed
mn list --action do          # Show only tasks
mn timeline                  # View chronological timeline
mn metrics                   # Analytics dashboard
```

## Full Documentation

See `QUICKSTART.md` for complete usage guide.

⚠️ **macOS Users**: If you get a security warning, see `MACOS-GATEKEEPER-FIX.md`

## Uninstall

```bash
./uninstall.sh
```

## Support

- Platform: darwin-arm64
- Version: 1.9.6
- Build: Wed Nov 26 03:07:47 EST 2025
