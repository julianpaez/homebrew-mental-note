# Mental Note CLI - Quick Start Guide

## Installation

### Binary Installation (Recommended - v1.1.0)
```bash
# Download for your platform:
# - macOS Apple Silicon: mental-note-v1.1.0-darwin-arm64.tar.gz (6.9MB)
# - macOS Intel: mental-note-v1.1.0-darwin-x64.tar.gz (build required)
# - Linux: mental-note-v1.1.0-linux-x64.tar.gz (build required)

# Extract the package
tar -xzf mental-note-v1.1.0-darwin-arm64.tar.gz
cd mental-note-v1.1.0-darwin-arm64

# Run the installer
./install.sh
```

**That's it!** Start using immediately:

```bash
mental-note add remember "Important meeting tomorrow"
mn add do "Complete project" --tags work,urgent
mn done 5                              # Mark task completed
mn timeline --since yesterday          # View timeline
mn metrics                             # See analytics
```

## Essential Commands

### Adding Notes
```bash
# Six action types with Unicode symbols
mn add remember "Information to recall"    # ● 
mn add do "Task to complete"               # ✓
mn add contemplate "Idea to think about"   # ?
mn add forget "Let this go"                # ✗
mn add ignore "Deliberately ignore"        # ○
mn add stick "Important reminder"          # ★

# With tags and due dates
mn add do "Fix bug #123" --tags urgent,backend --due tomorrow
mn add remember "Meeting notes" --tags work --due "2 hours"
```

### Template System - Save & Reuse Command Patterns
```bash
# Save command patterns you use frequently
mn template save work "add do --tags work,urgent"
mn template save meeting "add do --tags meeting,1:1 --due friday"
mn template save personal "add remember --tags personal"

# Use templates with new content
mn template use work "Review quarterly report"
mn template use meeting "Discuss team goals"
mn template use personal "Doctor appointment next week"

# Manage templates
mn template list                           # Show all saved templates
mn template edit work "add do --tags work,high-priority"  # Update template
mn template delete personal                # Remove template
```

### Batch Entry Mode - Add Multiple Related Notes
```bash
# Add multiple notes with shared context
mn many do --tags work,urgent
# > Fix payment processing bug
# > Update user documentation
# > Deploy security patch
# > (empty line to finish)
# ✓ Created 3 notes

# Meeting preparation with due date
mn many do --tags meeting,prep --due tomorrow
# > Prepare presentation slides
# > Review team metrics
# > Schedule follow-ups
# > (empty line to finish)
# ✓ Created 3 notes

# Personal reminders
mn many remember --tags personal
# > Pick up dry cleaning
# > Call dentist
# > Buy groceries
# > (empty line to finish)
# ✓ Created 3 notes
```

### Task Completion
```bash
# Mark tasks as done/undone
mn done 5                                  # Mark note 5 completed (☑)
mn undone 5                                # Mark note 5 not completed (✓)

# Filter by completion
mn list --completed                        # Show only completed notes
mn list --pending --action do             # Show pending tasks only
```

### Due Date Management
```bash
# Add notes with due dates (natural language parsing)
mn add do "Submit report" --due tomorrow
mn add remember "Call client" --due "2 hours"
mn add do "Team meeting" --due "Monday 2pm"
mn add do "Project deadline" --due "2025-12-15"

# Set/modify due dates for existing notes
mn due 5 tomorrow                          # Set due date for note 5
mn due 10 "next week"                      # Set due date for note 10
mn due 15 clear                            # Clear due date from note 15

# View due date information
mn list --due                              # Show only notes with due dates
mn list --overdue                          # Show only overdue notes
mn overdue                                 # Quick overdue summary

# Natural language examples:
# - Time: 2h, 30m, 1.5h, today, tomorrow, yesterday
# - Days: 3d, next week, this Friday, Monday
# - Dates: 2025-12-25, Dec 25, Christmas
# - Combined: "tomorrow 3pm", "next Monday 9am"
```

### Viewing & Filtering
```bash
# Basic listing
mn list                                    # All active notes
mn list --action do                        # Show only tasks
mn list --tags work,urgent                # Notes with both tags
mn list --since yesterday                 # Recent notes

# Due date filtering
mn list --due                              # Show only notes with due dates
mn list --overdue                          # Show only overdue notes
mn overdue                                 # Quick overdue view

# Advanced sorting & completion filtering
mn list --sort content                     # Alphabetical by content
mn list --sort date --reverse             # Oldest first
mn list --sort due                         # Sort by due date
mn list --action do --pending --tags work # Pending work tasks
```

### Timeline & Analytics
```bash
# Visual timeline view
mn timeline                                # Chronological view of all notes
mn timeline --since yesterday              # Recent timeline
mn timeline --action do                    # Tasks timeline only
mn timeline --tags work --reverse          # Work notes, newest first

# Comprehensive metrics
mn metrics                                 # Full analytics dashboard
mn metrics --archived                      # Include archived notes
```

### Searching & Managing  
```bash
# Search notes
mn search "meeting"                        # Find by keyword
mn search "project" --tags work --sort date

# Delete notes
mn delete 5                               # Single deletion
mn delete 1 2 3 --confirm                # Batch deletion

# Edit & archive
mn edit 5 --content "Updated text"
mn archive 10                             # Archive without deleting
mn archived                               # View archived notes
```

### Data Export & Import
```bash
# Export notes for backup
mn export                                 # Export to timestamped file
mn export --file mybackup.json           # Export to specific file
mn export --archived                     # Include archived notes

# Import notes from backup
mn import backup.json                     # Import from file
mn import --merge                         # Merge with existing (default)
mn import --replace                       # Replace all existing notes
```

## Workflow Examples

### Eliminating Repetitive Typing with Templates

**Before Templates (repetitive):**
```bash
mn add do "Review pull request #123" --tags code-review,urgent --due 2h
mn add do "Review pull request #124" --tags code-review,urgent --due 2h  
mn add do "Review pull request #125" --tags code-review,urgent --due 2h
# ... typing the same pattern repeatedly
```

**After Templates (efficient):**
```bash
# Save the pattern once
mn template save review "add do --tags code-review,urgent --due 2h"

# Reuse with different content
mn template use review "Review pull request #123"
mn template use review "Review pull request #124" 
mn template use review "Review pull request #125"
# Much faster and less error-prone!
```

### Sprint Planning with Batch Entry

**Team Sprint Planning Session:**
```bash
# Add all sprint tasks at once with shared context
mn many do --tags sprint-12,development --due "end of sprint"
# > Implement user authentication system
# > Add password reset functionality
# > Create user profile management
# > Write comprehensive unit tests
# > Update API documentation
# > Conduct security review
# > (empty line to finish)
# ✓ Created 6 notes

# Later, check sprint progress
mn list --tags sprint-12 --pending        # See remaining tasks
mn list --tags sprint-12 --completed      # See completed work
```

### Weekly Meeting Preparation

**Combining Templates and Batch Entry:**
```bash
# Save template for weekly 1:1 meetings
mn template save weekly-1on1 "add do --tags 1:1,sarah --due friday"

# Quick agenda preparation
mn template use weekly-1on1 "Review last week's goals"
mn template use weekly-1on1 "Discuss career development"

# Add multiple discussion topics
mn many do --tags 1:1,sarah,discussion --due friday  
# > Q4 project priorities
# > Team collaboration improvements
# > Training opportunities
# > (empty line to finish)
# ✓ Created 3 notes
```

### Project Management Workflow

**Template-Based Project Organization:**
```bash
# Create project-specific templates
mn template save bug-fix "add do --tags bugs,project-x,urgent --due 1d"
mn template save feature "add do --tags features,project-x --due 1w"
mn template save testing "add do --tags testing,project-x"

# Track different types of work
mn template use bug-fix "Fix login redirect issue"
mn template use feature "Add dark mode support"
mn template use testing "Write integration tests for API"

# Add multiple related tasks
mn many do --tags project-x,documentation --due "end of week"
# > Update README with new features
# > Create API documentation
# > Write deployment guide
# > Record demo video
# > (empty line to finish)
# ✓ Created 4 notes
```

## Management

### Installation & Updates
```bash
./manage.sh --install                     # Install/reinstall
./manage.sh --status                      # Check installation
./manage.sh --uninstall                   # Remove completely
./manage.sh                               # Interactive menu
```

### Backup & Restore
```bash
./manage.sh --export mybackup             # Backup notes
./manage.sh --import backup.json          # Restore notes
```

## Complex Filtering & Multi-Parameter Commands
### Advanced List Filtering
```bash
# Combine multiple filters for precise results
mn list --action do --tags work,urgent --pending --since yesterday --sort content --reverse

# Complex date range filtering with completion status
mn list --action do --before 2025-11-01 --completed --tags project,client --format cards

# Multi-tag filtering (requires ALL tags)
mn list --tags work,urgent,deadline --pending --sort date
```
### Timeline with Complex Filters
```bash
# Project timeline with specific constraints
mn timeline --tags project,client --action do --since 2025-10-01 --reverse

# Completed task timeline analysis
mn timeline --action do --completed --before yesterday --tags work
```

## Advanced Search & Show Operations
### Multi-Note Detail Views
```bash
# Show multiple specific notes with full details
mn show 5 10 15 20 25 --full

# Filter-based bulk viewing
mn show --action do --pending --tags urgent --full
mn show --tags work,project --completed --since yesterday
```

### Search with Complex Filtering
```bash
# Search within filtered subsets
mn search "meeting" --tags work,client --sort date --reverse
mn search "python" --archived --action remember --tags learning
```

## Batch Operations & Management
### Bulk Task Completion
```bash
# Mark multiple tasks as completed
mn done 5 10 15 20 25

# Complex workflow: find, review, then complete
mn list --action do --tags urgent --pending
mn show --action do --tags urgent --pending --full
mn done 3 7 12  # Complete the urgent ones
```
### Advanced Batch Deletion
```bash
# Delete multiple notes with confirmation skip
mn delete 1 2 3 4 5 6 7 8 9 10 --confirm

# Find and delete workflow
mn list --action forget --before 2025-10-01
mn delete 15 16 17 18 --confirm
```
### Complex Edit Operations
```bash
# Multi-parameter edits
mn edit 5 --content "Updated comprehensive content" --action remember --tags work,updated,important

# Change action type and reorganize
mn edit 10 --action stick --tags persistent,reminder --content "Weekly team sync every Tuesday"
```
## Data Management & Analysis
### Advance Export/Import
```bash
# Export with specific criteria
mn export --file "project-backup-$(date +%Y%m%d).json" --archived

# Strategic data migration
mn export --file full-backup.json --archived  # Full backup
mn import backup.json --replace               # Clean slate import
```
### Comprehensive Analytics
```bash
# Full analytics including archived data
mn metrics --archived

# Workflow: analyze, filter, and act
mn metrics                                    # See patterns
mn list --action do --pending --tags work    # Find work tasks
mn timeline --action do --tags work          # See work timeline
```

## Display Format Combinations
### Advanced Formatting
```bash
# Different views for different purposes
mn list --action do --pending --format kanban    # Kanban board view
mn list --tags project --format tree            # Tree grouped by date
mn timeline --tags work --action do             # Work task timeline
mn list --completed --format minimal            # Clean completed list
```

## Complex Workflow Examples
### Project Review Workflow
```bash
# 1. See all project work
mn list --tags project --sort date --reverse

# 2. Review pending items in detail
mn show --tags project --pending --full

# 3. View project timeline
mn timeline --tags project --since 2025-10-01

# 4. Complete finished tasks
mn done 12 15 18

# 5. Archive old completed items
mn list --tags project --completed --before 2025-10-15
mn archive 5 7 9
```

### Daily Productivity Analysis
```bash
# Morning: Plan and review
mn list --action do --pending --sort content
mn timeline --since yesterday
mn metrics

# Throughout day: Quick adds and completions
mn add do "New urgent task" --tags work,urgent
mn done 23

# Evening: Analysis and cleanup
mn list --completed --since today
mn metrics
mn export --file "daily-backup-$(date +%Y%m%d).json"
```

### Knowledge Management System
```bash
# Capture learning notes
mn add remember "Python async/await patterns" --tags learning,python,async
mn add contemplate "Microservices architecture trade-offs" --tags architecture,ideas

# Review and organize knowledge
mn list --action remember --tags learning --sort content
mn search "python" --tags learning --action remember
mn timeline --action remember --tags learning --since 2025-10-01
```

## Troubleshooting

### Installation Issues
```bash
# If commands not found after install:
echo $PATH  # Check if ~/.local/bin is included
export PATH="$PATH:~/.local/bin"  # Add manually if needed

# If permission errors:
chmod +x ~/.local/bin/mental-note
```

### Data Location
```bash
# Your notes are stored at:
ls ~/.mental-notes/
cat ~/.mental-notes/notes.json  # View raw data
```

### Uninstall (if needed)
```bash
./uninstall.sh
# Or manually:
rm -f ~/.local/bin/mental-note ~/.local/bin/mn
```
## Privacy Note

Mental Note CLI stores all data locally at `~/.mental-notes/notes.json`. No data is sent externally - everything stays on your computer.

## More Help

```bash
mental-note --help                        # Main help with examples
```

**Thank you for taking the time to test Mental Note CLI!** Your feedback is invaluable for making this tool better.

*Happy note-taking!*
