# macOS Gatekeeper Troubleshooting Guide

## The Problem
When you download and try to run the `mental-note` binary on macOS, you may see this error:
> "mental-note" can't be opened because Apple cannot check it for malicious software.

This happens because the binary is unsigned and macOS Gatekeeper blocks unsigned applications for security.

## Solutions (Choose One)

### Solution 1: Remove Quarantine (Recommended)
```bash
# Navigate to the binary location
cd mental-note-v1.0.0-darwin-arm64/

# Remove the quarantine attribute
xattr -d com.apple.quarantine mental-note

# Make executable and run
chmod +x mental-note
./mental-note --help
```

### Solution 2: System Settings Override
1. Try to run the binary (it will show the error)
2. Go to **System Settings** → **Privacy & Security**
3. Scroll down to find "mental-note was blocked"
4. Click **"Allow Anyway"**
5. Try running again and click **"Open"**

### Solution 3: Terminal Override
```bash
# Allow the binary to run
sudo spctl --add mental-note

# Test it
./mental-note --help
```

## Why This Happens
- macOS Gatekeeper protects users from malicious software
- Downloaded binaries get a "quarantine" attribute
- Unsigned binaries are blocked by default
- This is normal and expected behavior
